-- made by isar23
-- setup for MoveOut

DROP DATABASE IF EXISTS moveout;
CREATE DATABASE moveout;
USE moveout;
