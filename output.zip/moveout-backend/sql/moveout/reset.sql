--
-- Reset for MoveOut
-- Must be in folder '/sql/moveout'

source setup.sql;
source ddl.sql;
